LINKGO — demo Safelink sederhana

CARA MENJALANKAN
1. Ekstrak ZIP.
2. Buka index.html di browser HP untuk mencoba.
3. Untuk membuatnya online, unggah index.html ke hosting statis seperti GitHub Pages atau Netlify.

CARA MEMBUAT LINK
- Buka website LINKGO yang sudah online.
- Tempel URL tujuan yang valid.
- Tekan Buat.
- Salin URL halaman yang muncul di address bar untuk dibagikan.

CATATAN PENTING
- Ini adalah prototipe front-end. Belum ada database, dashboard admin, atau statistik pengunjung lintas perangkat.
- Kotak iklan hanya placeholder, bukan iklan aktif dan belum menghasilkan uang.
- Monetisasi memerlukan akun penyedia iklan, persetujuan situs, halaman/konten yang memenuhi kebijakan, serta konfigurasi kode iklan resmi.
- Jangan klik iklan sendiri, membeli klik, atau meminta pengunjung mengeklik iklan.
- Gunakan untuk tautan yang berhak kamu bagikan; tampilkan domain tujuan dengan jelas.
- Untuk produksi, tambahkan halaman Privasi, Kontak, Tentang, dan ketentuan penggunaan.
